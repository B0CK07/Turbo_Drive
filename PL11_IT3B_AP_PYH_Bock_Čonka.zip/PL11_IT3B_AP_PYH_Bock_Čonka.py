import pygame
import sys
import os
import tkinter as tk
import random
from tkinter import messagebox

root = tk.Tk()
root.withdraw()

pygame.init()
WIDTH, HEIGHT = 1024, 1024
WIN = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
pygame.display.set_caption("Drive or Die")

BG_COLOR = (30, 0, 30)
BUTTON_COLOR = (60, 30, 60)
TEXT_COLOR = (220, 255, 220)
TITLE_COLOR = (200, 150, 50)

FONT = pygame.font.Font(pygame.font.get_default_font(), 50)
TITLE_FONT = pygame.font.Font(pygame.font.get_default_font(), 80)

difficulty = "normal"
selected_map = None
game_started = False
transitioning = False
score = 0
road_y = 0
speed_multiplier = 1.0
spawn_chance = 2
control_scheme = "wasd"  # default control scheme

ASSET_PATH = os.path.join("assets", "Auto.png")
CAR_IMAGE = pygame.image.load(ASSET_PATH)
CAR_IMAGE = pygame.transform.scale(CAR_IMAGE, (91, 164))

OBSTACLE_IMAGE = pygame.image.load(os.path.join("assets", "prekazka.png"))
OBSTACLE_IMAGE = pygame.transform.scale(OBSTACLE_IMAGE, (60, 60))

MAPS = {
    "desert": pygame.image.load("desert.png"),
    "forest": pygame.image.load("forest.png"),
    "city": pygame.image.load("city.png")
}

def get_scaled_bg():
    return pygame.transform.scale(pygame.image.load("assets/Background.png"), WIN.get_size())

def confirm_quit():
    return messagebox.askyesno("Ukončit hru", "Opravdu chcete hru ukončit?")

def update_speed_multiplier():
    global speed_multiplier, spawn_chance
    speed_multiplier = 1.0 + (score // 100) * 0.2
    spawn_chance = max(2, 2 + (score // 100) * 1)

class Obstacle:
    def __init__(self):
        self.x = random.randint(248, 1024 - 248 - 60)  # 60 je šířka překážky
        self.y = -60
        self.image = OBSTACLE_IMAGE

    def move(self):
        base_speed = {"easy": 10, "normal": 15, "hard": 25}
        if not game_started:
            return
        elif game_started and not transitioning:
            self.y += 5
        else:
            self.y += base_speed.get(difficulty, 7.5) * speed_multiplier

    def draw(self, win):
        win.blit(self.image, (self.x, self.y))

    def check_collision(self, player_x, player_y):
        return self.x < player_x + 80 and self.x + 60 > player_x and self.y < player_y + 100 and self.y + 60 > player_y

obstacles = []

def spawn_obstacle():
    obstacles.append(Obstacle())

def draw_obstacles(player, paused):
    global obstacles
    road_width = WIN.get_size()[0] * 2 // 4
    road_x = (WIN.get_size()[0] - road_width) // 2
    road_right = road_x + road_width

    if not paused and random.randint(1, 100) <= spawn_chance:
        spawn_obstacle()

    for obstacle in obstacles:
        if not paused:
            obstacle.move()
        obstacle.draw(WIN)
        if obstacle.check_collision(player.x, player.y):
            game_over()

class Player:
    def __init__(self, x, y):
        self.original_image = pygame.image.load(os.path.join("assets", "Auto.png"))
        self.image = pygame.transform.scale(self.original_image, (91, 164))
        self.x = x
        self.y = y + 200
        self.speed_forward = 5
        self.speed_backward = 3

    def move(self, keys):
        global game_started
        center_x = (WIN.get_width()) // 2

        if control_scheme == "wasd":
            left, right, up = pygame.K_a, pygame.K_d, pygame.K_w
        else:
            left, right, up = pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP

        if keys[left]:
            rotated_image = pygame.transform.rotate(self.original_image, 33.75)
            self.image = rotated_image
            self.x -= self.speed_forward
        elif keys[right]:
            rotated_image = pygame.transform.rotate(self.original_image, -33.75)
            self.image = rotated_image
            self.x += self.speed_forward
        elif keys[up]:
            game_started = True
        else:
            self.image = pygame.transform.scale(self.original_image, (91, 164))

        if self.x < center_x - (528/2):
            self.x = center_x - (528/2)
            self.image = pygame.transform.scale(self.original_image, (91, 164))
        if self.x + 91 > center_x + (528/2):
            self.x = center_x + (528/2) - 91
            self.image = pygame.transform.scale(self.original_image, (91, 164))

    def draw(self, win):
        win.blit(self.image, (self.x, self.y))

def draw_score(score):
    text_surface = FONT.render(f"Score: {score}", True, TEXT_COLOR)
    WIN.blit(text_surface, (10, 10))

def draw_road(paused=False):
    global road_y, transitioning, score, difficulty
    WIN.blit(get_scaled_bg(), (0, 0))
    road_texture_origo = pygame.transform.scale(MAPS[selected_map], [1024,1024])
    center_x = (WIN.get_width() - road_texture_origo.get_width()) // 2

    base_speed = {"easy": 10, "normal": 15, "hard": 25}

    if not game_started:
        WIN.blit(road_texture_origo, (center_x, 0))
    elif game_started and not transitioning:
        road_texture = pygame.image.load(f"{selected_map}2.png")
        road_texture = pygame.transform.scale(road_texture, [1024,1024])
        WIN.blit(road_texture_origo, (center_x, road_y))
        WIN.blit(road_texture, (center_x, road_y - WIN.get_height()))
        if not paused:
            road_y += 5
            if road_y >= WIN.get_height():
                score += 10
                update_speed_multiplier()
                transitioning = True
    else:
        road_texture = pygame.image.load(f"{selected_map}_loop.png")
        road_texture = pygame.transform.scale(road_texture, [1024,1024])
        WIN.blit(road_texture, (center_x, road_y))
        WIN.blit(road_texture, (center_x, road_y - WIN.get_height()))
        if not paused:
            road_y += base_speed.get(difficulty, 7.5) * speed_multiplier
            if road_y >= WIN.get_height():
                score += 10
                update_speed_multiplier()
                road_y = 0

def game_over():
    global obstacles, score, road_y, game_started, transitioning, speed_multiplier, spawn_chance
    WIN.fill((0, 0, 0))
    text_surface = TITLE_FONT.render("GAME OVER!", True, (255, 0, 0))
    WIN.blit(text_surface, (WIN.get_size()[0]//2 - text_surface.get_width()//2, WIN.get_size()[1]//2))
    pygame.display.update()
    pygame.time.delay(2000)
    obstacles.clear()
    score = 0
    road_y = 0
    game_started = False
    transitioning = False
    speed_multiplier = 1.0
    spawn_chance = 2
    menu_loop()

def draw_options(selected):
    width, height = WIN.get_size()
    WIN.blit(get_scaled_bg(), (0, 0))
    title_surface = TITLE_FONT.render("OPTIONS", True, TITLE_COLOR)
    WIN.blit(title_surface, (width//2 - title_surface.get_width()//2, height//12))
    btn_width, btn_height = width // 5, height // 14
    spacing = height // 40
    y_start = height // 4
    buttons = []

    difficulties = ["easy", "normal", "hard"]
    control_labels = ["wasd", "arrows"]

    for i, (diff, ctrl) in enumerate(zip(difficulties, control_labels + [None])):
        # Difficulty button on left
        diff_rect = pygame.Rect(width//4 - btn_width//2, y_start + i * (btn_height + spacing), btn_width, btn_height)
        diff_color = (100, 200, 100) if diff == selected else BUTTON_COLOR
        pygame.draw.rect(WIN, diff_color, diff_rect)
        diff_text = FONT.render(diff.upper(), True, TEXT_COLOR)
        WIN.blit(diff_text, diff_text.get_rect(center=diff_rect.center))
        buttons.append((diff, diff_rect))

        # Control button on right (if exists)
        if ctrl:
            ctrl_rect = pygame.Rect(3*width//4 - btn_width//2, y_start + i * (btn_height + spacing), btn_width, btn_height)
            ctrl_color = (100, 200, 100) if control_scheme == ctrl else BUTTON_COLOR
            pygame.draw.rect(WIN, ctrl_color, ctrl_rect)
            ctrl_text = FONT.render(ctrl.upper(), True, TEXT_COLOR)
            WIN.blit(ctrl_text, ctrl_text.get_rect(center=ctrl_rect.center))
            buttons.append((ctrl, ctrl_rect))

    back_rect = pygame.Rect(width//2 - btn_width//2, y_start + 4 * (btn_height + spacing), btn_width, btn_height)
    pygame.draw.rect(WIN, BUTTON_COLOR, back_rect)
    back_surface = FONT.render("BACK", True, TEXT_COLOR)
    WIN.blit(back_surface, back_surface.get_rect(center=back_rect.center))
    buttons.append(("back", back_rect))

    pygame.display.update()
    return buttons


def options_loop():
    global difficulty, control_scheme
    while True:
        buttons = draw_options(difficulty)
        for event in pygame.event.get():
            if event.type == pygame.QUIT and confirm_quit():
                pygame.quit()
                sys.exit()
            if event.type == pygame.VIDEORESIZE:
                pygame.display.set_mode(event.size, pygame.RESIZABLE)
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for text, rect in buttons:
                    if rect.collidepoint(event.pos):
                        if text == "back":
                            return
                        elif text in ["wasd", "arrows"]:
                            control_scheme = text
                        else:
                            difficulty = text

def map_selection_loop():
    global selected_map
    while True:
        width, height = WIN.get_size()
        WIN.blit(get_scaled_bg(), (0, 0))
        title_surface = TITLE_FONT.render("VYBER MAPU", True, TITLE_COLOR)
        WIN.blit(title_surface, (width//2 - title_surface.get_width()//2, height//8))
        btn_width, btn_height = width // 4, height // 8
        spacing = height // 10
        y_start = height // 3
        labels = list(MAPS.keys())
        buttons = []
        for i, text in enumerate(labels):
            rect = pygame.Rect(width//2 - btn_width//2, y_start + i * (btn_height + spacing), btn_width, btn_height)
            pygame.draw.rect(WIN, BUTTON_COLOR, rect)
            text_surface = FONT.render(text.upper(), True, TEXT_COLOR)
            text_rect = text_surface.get_rect(center=rect.center)
            WIN.blit(text_surface, text_rect)
            buttons.append((text, rect))
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT and confirm_quit():
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for text, rect in buttons:
                    if rect.collidepoint(event.pos):
                        selected_map = text
                        return

def draw_menu():
    width, height = WIN.get_size()
    WIN.blit(get_scaled_bg(), (0, 0))
    title_surface = TITLE_FONT.render("MENU", True, TITLE_COLOR)
    WIN.blit(title_surface, (width//2 - title_surface.get_width()//2, height//8))
    btn_width, btn_height = width // 3, height // 12
    spacing = height // 10
    y_start = height // 3
    labels = ["PLAY", "OPTIONS", "QUIT"]
    buttons = []
    for i, text in enumerate(labels):
        rect = pygame.Rect(width//2 - btn_width//2, y_start + i * (btn_height + spacing), btn_width, btn_height)
        pygame.draw.rect(WIN, BUTTON_COLOR, rect)
        text_surface = FONT.render(text, True, TEXT_COLOR)
        text_rect = text_surface.get_rect(center=rect.center)
        WIN.blit(text_surface, text_rect)
        buttons.append((text, rect))
    pygame.display.update()
    return buttons

def game_loop():
    global WIN, score
    clock = pygame.time.Clock()
    width, height = WIN.get_size()
    player = Player(width//2 - 30, height//2 - 50)
    paused = False
    while True:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT and confirm_quit():
                pygame.quit()
                sys.exit()
            if event.type == pygame.VIDEORESIZE:
                WIN = pygame.display.set_mode(event.size, pygame.RESIZABLE)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                paused = not paused
            if paused and event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for text, rect in draw_pause_menu():
                    if rect.collidepoint(event.pos):
                        if text == "Pokračovat":
                            paused = False
                        elif text == "Ukončit hru" and confirm_quit():
                            pygame.quit()
                            sys.exit()
                        elif text == "Menu":
                            return

        keys = pygame.key.get_pressed()
        if not paused:
            player.move(keys)

        draw_road(paused)
        player.draw(WIN)
        draw_obstacles(player, paused)
        draw_score(score)

        if paused:
            draw_pause_menu()

        pygame.display.update()

def draw_pause_menu():
    width, height = WIN.get_size()
    pause_text = TITLE_FONT.render("PAUSED", True, TITLE_COLOR)
    WIN.blit(pause_text, (width // 2 - pause_text.get_width() // 2, height // 4))

    btn_width, btn_height = width // 4, height // 10
    spacing = height // 15
    y_start = height // 2

    buttons = []
    labels = ["Pokračovat", "Ukončit hru", "Menu"]
    for i, label in enumerate(labels):
        rect = pygame.Rect(width // 2 - btn_width // 2, y_start + i * (btn_height + spacing), btn_width, btn_height)
        pygame.draw.rect(WIN, BUTTON_COLOR, rect)
        text_surf = FONT.render(label, True, TEXT_COLOR)
        text_rect = text_surf.get_rect(center=rect.center)
        WIN.blit(text_surf, text_rect)
        buttons.append((label, rect))

    pygame.display.update()
    return buttons

def menu_loop():
    while True:
        buttons = draw_menu()
        for event in pygame.event.get():
            if event.type == pygame.QUIT and confirm_quit():
                pygame.quit()
                sys.exit()
            if event.type == pygame.VIDEORESIZE:
                pygame.display.set_mode(event.size, pygame.RESIZABLE)
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for text, rect in buttons:
                    if rect.collidepoint(event.pos):
                        if text == "PLAY":
                            map_selection_loop()
                            game_loop()
                        elif text == "OPTIONS":
                            options_loop()
                        elif text == "QUIT" and confirm_quit():
                            pygame.quit()
                            sys.exit()

menu_loop()